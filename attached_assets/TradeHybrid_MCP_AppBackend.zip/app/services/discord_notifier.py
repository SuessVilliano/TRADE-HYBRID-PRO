import httpx

WEBHOOK = "https://discord.com/api/webhooks/1366872425350037625/Tk_tIqARv4jJAGBu5298r1YC64lxPQZyR9uG67TD-OFt__9p1T4IiH42m8KVMpgUiuZX"

async def send_discord_alert(content):
    try:
        async with httpx.AsyncClient() as client:
            await client.post(WEBHOOK, json={"content": content})
    except Exception as e:
        print("Discord error:", e)
