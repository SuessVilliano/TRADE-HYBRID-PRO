import asyncio, json
from datetime import datetime, timedelta
from app.services.price_fetcher import fetch_price
from app.services.discord_notifier import send_discord_alert
from app.services.config import get_provider

class TradeManager:
    def __init__(self):
        self.trades = {}
        self.results = []
        self.latest_prices = {}
        self.load()

    async def add_trade(self, trade):
        symbol = trade["symbol"]
        trade["created_at"] = datetime.utcnow().isoformat()
        trade["expires_at"] = (datetime.utcnow() + timedelta(minutes=trade.get("max_lifespan_minutes", 240))).isoformat()
        trade["provider"] = trade.get("provider") or get_provider(symbol)
        trade["status"] = "open"
        self.trades[symbol] = trade
        asyncio.create_task(self.monitor_trade(symbol))
        self.save()
        await send_discord_alert(f"🚀 {trade['provider']} Signal: {trade['symbol']} {trade['direction'].upper()} | Entry: {trade['entry_price']}")
        return {"status": "tracking", "trade": trade}

    async def monitor_trade(self, symbol):
        while symbol in self.trades:
            trade = self.trades[symbol]
            if datetime.utcnow() > datetime.fromisoformat(trade["expires_at"]):
                trade["status"] = "expired"
                await self.close_trade(symbol, trade)
                break
            price = await fetch_price(symbol)
            if price:
                self.latest_prices[symbol] = price
                if self.check_hit(trade, price):
                    await self.close_trade(symbol, trade)
                    break
            await asyncio.sleep(60)

    def check_hit(self, trade, price):
        if trade["direction"] == "buy":
            if price <= trade["stop_loss"]: trade["hit"] = "stop_loss"; return True
            for i in range(1, 4):
                if trade.get(f"take_profit_{i}") and price >= trade[f"take_profit_{i}"]:
                    trade["hit"] = f"take_profit_{i}"
                    return True
        else:
            if price >= trade["stop_loss"]: trade["hit"] = "stop_loss"; return True
            for i in range(1, 4):
                if trade.get(f"take_profit_{i}") and price <= trade[f"take_profit_{i}"]:
                    trade["hit"] = f"take_profit_{i}"
                    return True
        return False

    async def close_trade(self, symbol, trade):
        trade["status"] = "closed"
        self.results.append(trade)
        self.trades.pop(symbol, None)
        await send_discord_alert(f"✅ Trade Closed: {trade['symbol']} | Result: {trade.get('hit', 'expired').upper()}")
        self.save()

    def cancel_trade(self, symbol):
        trade = self.trades.pop(symbol, None)
        if trade:
            trade["status"] = "cancelled"
            self.results.append(trade)
            self.save()
            return {"status": "cancelled", "trade": trade}
        return {"error": "not found"}

    def get_filtered_trades(self):
        return self.trades

    def get_trade_stats(self):
        total = len(self.results)
        wins = sum(1 for r in self.results if r.get("hit", "").startswith("take_profit"))
        losses = sum(1 for r in self.results if r.get("hit") == "stop_loss")
        providers = {}
        for r in self.results:
            p = r["provider"]
            if p not in providers:
                providers[p] = {"wins": 0, "losses": 0}
            if r.get("hit", "").startswith("take_profit"):
                providers[p]["wins"] += 1
            elif r.get("hit") == "stop_loss":
                providers[p]["losses"] += 1
        return {"total": total, "wins": wins, "losses": losses, "by_provider": providers}

    def save(self):
        with open("app/db/db.json", "w") as f:
            json.dump({"active": self.trades, "results": self.results}, f)

    def load(self):
        try:
            with open("app/db/db.json", "r") as f:
                data = json.load(f)
                self.trades = data.get("active", {})
                self.results = data.get("results", [])
        except:
            pass

trade_manager = TradeManager()
