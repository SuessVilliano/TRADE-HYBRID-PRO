import httpx

SYMBOL_MAP = {
    "BTC/USD": "bitcoin",
    "ETH/USD": "ethereum",
    "SOL/USD": "solana"
}

async def fetch_price(symbol):
    if symbol in SYMBOL_MAP:
        return await fetch_coingecko_price(SYMBOL_MAP[symbol])
    return await fetch_twelvedata_price(symbol)

async def fetch_coingecko_price(name):
    try:
        url = f"https://api.coingecko.com/api/v3/simple/price?ids={name}&vs_currencies=usd"
        async with httpx.AsyncClient() as client:
            r = await client.get(url)
            return r.json()[name]["usd"]
    except:
        return None

async def fetch_twelvedata_price(symbol):
    try:
        url = f"https://api.twelvedata.com/price?symbol={symbol.replace('/', '')}&apikey=demo"
        async with httpx.AsyncClient() as client:
            r = await client.get(url)
            return float(r.json().get("price"))
    except:
        return None

async def fetch_all_prices():
    pairs = ["BTC/USD", "ETH/USD", "SOL/USD", "EUR/USD", "GBP/USD", "USD/JPY", "XAU/USD", "NQ1!"]
    return {p: await fetch_price(p) for p in pairs}
