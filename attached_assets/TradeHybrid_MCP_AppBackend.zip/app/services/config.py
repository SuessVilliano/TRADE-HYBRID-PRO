def get_provider(symbol):
    if "BTC" in symbol or "ETH" in symbol or "SOL" in symbol:
        return "Paradox AI"
    elif any(fx in symbol for fx in ["EUR", "GBP", "JPY", "USD"]):
        return "Solaris AI"
    elif "NQ" in symbol or "SPX" in symbol or "MQ" in symbol:
        return "Hybrid AI"
    return "TradeHybrid AI"
