from fastapi import APIRouter, Request
from app.services.trade_manager import trade_manager
from app.services.price_fetcher import fetch_all_prices

router = APIRouter()

@router.post("/trade-signal")
async def trade_signal(request: Request):
    data = await request.json()
    return await trade_manager.add_trade(data)

@router.get("/refresh-data")
async def refresh_data():
    return await fetch_all_prices()

@router.get("/active-trades")
async def active_trades():
    return trade_manager.get_filtered_trades()

@router.get("/trade-stats")
async def trade_stats():
    return trade_manager.get_trade_stats()

@router.post("/cancel-trade")
async def cancel_trade(request: Request):
    data = await request.json()
    return trade_manager.cancel_trade(data["symbol"])
