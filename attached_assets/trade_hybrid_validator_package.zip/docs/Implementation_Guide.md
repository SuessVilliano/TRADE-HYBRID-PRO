# Implementation Guide

## Prerequisites
- Rust >= 1.60
- Anchor CLI
- Node.js & npm
- Solana CLI
- Yarn or npm

## Anchor Programs
1. **Dual Rewards**  
   - Path: `anchor-programs/dual_rewards`  
   - Deploy:  
     ```bash
     anchor build
     anchor deploy
     ```

2. **Staking-as-a-Service Factory**  
   - Path: `anchor-programs/staking_saas_factory`  
   - Deploy similarly.

3. **NFT Boost**  
   - Path: `anchor-programs/nft_boost`  
   - Ensure SPL Token dependency.

## Airdrop Bot
- Install deps:
  ```bash
  npm install @solana/web3.js @project-serum/anchor
  ```
- Configure keypair path in `scripts/airdrop_bot.js`.
- Run:
  ```bash
  node scripts/airdrop_bot.js
  ```

## Frontend Prototype (Replit)
- Use the Anchor-generated IDLs in your React app.
- Fetch user stake account data via Solana Web3.js.
- Call program methods through Anchor Provider.

## Next Steps
- Build referral/dashboard frontend.
- Integrate NFT boost checks.
- Develop Prop DAO governance UI.
