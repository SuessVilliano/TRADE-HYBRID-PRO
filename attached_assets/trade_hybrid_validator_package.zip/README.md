# Trade Hybrid Validator Package

Contains Anchor programs for:
- Dual Rewards airdrop
- Staking-as-a-Service factory
- NFT Boost multipliers

Also includes:
- Airdrop bot script
- Detailed implementation guide
