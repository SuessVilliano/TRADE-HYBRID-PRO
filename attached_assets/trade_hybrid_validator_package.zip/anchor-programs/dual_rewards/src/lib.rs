use anchor_lang::prelude::*;

declare_id!("DualRewProg1111111111111111111111111111111");

#[program]
pub mod dual_rewards {
    use super::*;
    pub fn initialize(ctx: Context<Initialize>, base_rate: u64) -> Result<()> {
        let state = &mut ctx.accounts.state;
        state.base_rate = base_rate;
        Ok(())
    }

    pub fn airdrop_rewards(ctx: Context<AirdropRewards>) -> Result<()> {
        // TODO: Implement reward distribution logic
        Ok(())
    }
}

#[account]
pub struct State {
    pub base_rate: u64,
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(init, payer = user, space = 8 + 8)]
    pub state: Account<'info, State>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AirdropRewards<'info> {
    pub state: Account<'info, State>,
    // Add other accounts as needed for CPI to token program
}
