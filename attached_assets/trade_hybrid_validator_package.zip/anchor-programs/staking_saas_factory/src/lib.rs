use anchor_lang::prelude::*;

declare_id!("StakSaAsProg1111111111111111111111111111111");

#[program]
pub mod staking_saas_factory {
    use super::*;
    pub fn create_pool(ctx: Context<CreatePool>, rate: u64) -> Result<()> {
        let pool = &mut ctx.accounts.pool;
        pool.rate = rate;
        pool.owner = *ctx.accounts.user.key;
        Ok(())
    }
}

#[account]
pub struct Pool {
    pub rate: u64,
    pub owner: Pubkey,
}

#[derive(Accounts)]
pub struct CreatePool<'info> {
    #[account(init, payer = user, space = 8 + 8 + 32)]
    pub pool: Account<'info, Pool>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}
