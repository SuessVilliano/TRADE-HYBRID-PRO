use anchor_lang::prelude::*;
use anchor_spl::token::TokenAccount;

declare_id!("NftBoostProg111111111111111111111111111111111");
    
#[program]
pub mod nft_boost {
    use super::*;
    pub fn claim_boost(ctx: Context<ClaimBoost>) -> Result<()> {
        // TODO: Verify NFT ownership and issue bonus
        Ok(())
    }
}

#[derive(Accounts)]
pub struct ClaimBoost<'info> {
    #[account(mut)]
    pub user: Signer<'info>,
    pub nft_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub boost_state: Account<'info, BoostState>,
}

#[account]
pub struct BoostState {
    pub multiplier: u8,
}
